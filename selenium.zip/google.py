from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time #버퍼링 시간 넣어줄때
import urllib.request
import json


options = webdriver.ChromeOptions()
options.add_experimental_option("excludeSwitches", ["enable-logging"])
driver = webdriver.Chrome(options=options)


driver.get("https://kr.investing.com/commodities/aluminum-historical-data") #investing 알루미늄 선물 내역

driver.find_element_by_id("widgetFieldDateRange").click() #달력누르기
driver.implicitly_wait(5)
elem1=driver.find_element_by_id("startDate")
elem1.clear()
elem1.send_keys("10/01/01")#시작날짜 17년 1월 1일로 다시 세팅

driver.find_element_by_id("applyBtn").click() #달력누르기

doc_list=[]
table=driver.find_element_by_id("curr_table")
tbody = table.find_element_by_tag_name("tbody") #tbody 접근
rows = tbody.find_elements_by_tag_name("tr") #tr접근
for index, value in enumerate(rows):
    date=value.find_elements_by_tag_name("td")[0] #date값 접근
    price=value.find_elements_by_tag_name("td")[1] #알루미늄 선물 값 접근
    doc = {
            'date': date.text,
            'al_price': price.text,
        }
    doc_list.append(doc)


with open("data.json", "w") as f:
    json.dump(doc_list, f)


# driver = webdriver.Chrome()
# driver.get("https://www.google.co.kr/imghp?hl=ko&ogbl/")


# driver.find_element_by_xpath('/html/body/div[3]/div[2]/div[2]/div[4]/table/tbody/tr[5]/td[1]/a').click() #알루미늄합금 누르기

# table = driver.find_element_by_class_name('tbl_exchange today') # 테이블
# print(table.txt)


# iframes = driver.find_elements_by_css_selector('iframe') #iframe이 여러개 있을 경우를 대비
# for iframe in iframes:
#     print(iframe.get_attribute('name'))

# # 만약 iframe이 많으시다면,
# iframes = driver.find_elements_by_tag_name('iframe')

# # iframe의 name을 출력한 후,
# for iframe in iframes:
# 	print(iframe.get_attribute('name'))
# driver.switch_to.default_content()

# element = driver.find_element_by_tag_name('iframe')
# driver.switch_to.frame(element)


# iframe=driver.find_element_by_css_selector('iframe')
# driver.switch_to.frame(iframe)


# date=driver.find_element_by_xpath('/html/body/div/table/tbody/tr[1]/td[1]')
# Al_price=driver.find_element_by_xpath('/html/body/div/table/tbody/tr[1]/td[2]')

# print(date.text)
# print(Al_price.text)
# elem = driver.find_element_by_name("q") #화면 내 F12를 통해 확인한 검색창 NAME = q 이기때문
# elem.send_keys("조코딩")
# elem.send_keys(Keys.RETURN)

# SCROLL_PAUSE_TIME = 1

# # Get scroll height
# last_height = driver.execute_script("return document.body.scrollHeight")

# while True:
#     # Scroll down to bottom
#     driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")

#     # Wait to load page
#     time.sleep(SCROLL_PAUSE_TIME)

#     # Calculate new scroll height and compare with last scroll height
#     new_height = driver.execute_script("return document.body.scrollHeight")
#     if new_height == last_height:
#         try:
#             driver.find_element_by_css_selector(".mye4qd").click()
#         except:
#             break
#     last_height = new_height

# #클래스니까  앞과 공백에 .을 붙인다, click을 위해 뒤에 붙인다
# #driver.find_elements_by_css_selector(".rg_i.Q4LuWd")[0].click()

# images = driver.find_elements_by_css_selector(".rg_i.Q4LuWd")
# count=1
# for image in images :
#     try:
#         image.click()
#         time.sleep(2)
#         #imgUrl =driver.find_element_by_css_selector(".n3VNCb").get_attribute("src")
#         imgUrl =driver.find_element_by_xpath("/html/body/div[2]/c-wiz/div[3]/div[2]/div[3]/div/div/div[3]/div[2]/c-wiz/div/div[1]/div[1]/div[2]/div/a/img").get_attribute("src")
#         urllib.request.urlretrieve(imgUrl, str(count) +".jpg")
#         count=count+1
#     except:
#         pass

# driver.close() #마지막 드라이버 닫아주기

# assert "Python" in driver.title
# elem = driver.find_element_by_name("q")
# elem.clear()
# elem.send_keys("pycon")
# elem.send_keys(Keys.RETURN)
# assert "No results found." not in driver.page_source
# driver.close()