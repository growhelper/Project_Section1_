
import time
import copy
import requests

# octokit = ''
# dont_touch= []
# response = requests.get("https://api.github.com/users/octokit/repos")
# 주의할 점 : github API 는 호출이 너무 많이 발생하면 자체적으로 제한을 걸 수 있습니다.
# 한번의 API 호출 후 1초 sleep 시간을 지정합니다.
time.sleep(1)

# if response.status_code == 200:
#     octokit = response.json()
#     dont_touch = copy.deepcopy(octokit)

"""
MONGODB SETUP
"""
from pymongo import MongoClient

HOST = 'cluster0.dxgf4.mongodb.net'
USER = 'taewoo'
PASSWORD = 'taewoo1234'
DATABASE_NAME = 'myFirstDatabase'
COLLECTION_NAME = 'al_price'
MONGO_URI = f"mongodb+srv://{USER}:{PASSWORD}@{HOST}/{DATABASE_NAME}?retryWrites=true&w=majority"

"""
위 코드는 힌트입니다. 자신에 맞는 HOST,USER, PASSWORD, DATABASE_NAME 을 입력하세요
! COLLECTION_NAME = 'octokit_repos'
아래 pass 를 지우고 코드를 작성하세요

- 데이터베이스와 연결한 뒤 Collection 이라는 테이블과 연결하는 작업이 가장 오래걸리실 겁니다.
"""
import json

with open('C:/Users/KIMLEE/Documents/SECTION3_HW/selenium/data.json', 'r') as f:
    trend_data = json.load(f)


client = MongoClient(MONGO_URI)
database = client[DATABASE_NAME]
collection = database[COLLECTION_NAME]
collection.insert_many(trend_data)

