from pymongo import MongoClient
import time
import copy
import requests

al_price = ''
dont_touch= []
# response = requests.get("https://api.github.com/users/octokit/repos")
# # 주의할 점 : github API 는 호출이 너무 많이 발생하면 자체적으로 제한을 걸 수 있습니다.
# # 한번의 API 호출 후 1초 sleep 시간을 지정합니다.
# time.sleep(1)

if response.status_code == 200:
    al_price = response.json()
    dont_touch = copy.deepcopy(al_price)

# """
# MONGODB SETUP
# """
from pymongo import MongoClient

HOST = 'cluster0.dxgf4.mongodb.net'
USER = 'taewoo'
PASSWORD = 'taewoo1234'
DATABASE_NAME = 'myFirstDatabase'
COLLECTION_NAME = 'al_price'
MONGO_URI = f"mongodb+srv://{USER}:{PASSWORD}@{HOST}/{DATABASE_NAME}?retryWrites=true&w=majority"



client = MongoClient(MONGO_URI)
database = client[DATABASE_NAME]
collection = database[COLLECTION_NAME]
collection.insert_many(al_price)