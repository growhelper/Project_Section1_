import requests
from bs4 import BeautifulSoup

import json
headers = {
    'authority': 'search.shopping.naver.com',
    'pragma': 'no-cache',
    'cache-control': 'no-cache',
    'sec-ch-ua': '"Chromium";v="94", "Google Chrome";v="94", ";Not A Brand";v="99"',
    'accept': 'application/json, text/plain, */*',
    'sec-ch-ua-mobile': '?0',
    'logic': 'PART',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.61 Safari/537.36',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'cors',
    'sec-fetch-dest': 'empty',
    'referer': 'https://search.shopping.naver.com/search/all?query=%EC%95%8C%EB%A3%A8%EB%AF%B8%EB%8A%84%ED%8C%90%20T%20MM&frm=NVSHATC&prevQuery=%EC%95%8C%EB%A3%A8%EB%AF%B8%EB%8A%84%ED%8C%90%20T%20MM',
    'accept-language': 'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7',
    'cookie': 'NNB=M5K7OKF7DDPWA; ASID=7db03a920000017bf48159970000006a; MM_NEW=1; NFS=2; nx_ssl=2; nid_inf=40034018; NID_JKL=ollfQxaXnqnUiGsra19YwAJU5lCBOP82RV3Yq8s3oyc=; AD_SHP_BID=27; _shopboxeventlog=false; page_uid=hTMXmsprvhGssfY8Y0RssssstRZ-087817; spage_uid=hTMXmsprvhGssfY8Y0RssssstRZ-087817; BMR=; sus_val=HgzHbBWy54JohvwhpfO9GiAs',
}
doc2_list=[]
for i in range(1,100):
    try:
        params = (
            ('sort', 'rel'),
            ('pagingIndex', i),
            ('pagingSize', '80'),
            ('viewType', 'list'),
            ('productSet', 'total'),
            ('deliveryFee', ''),
            ('deliveryTypeValue', ''),
            ('frm', 'NVSHATC'),
            ('query', '\uC54C\uB8E8\uBBF8\uB284\uD310 T MM'),
            ('origQuery', '\uC54C\uB8E8\uBBF8\uB284\uD310 T MM'),
            ('iq', ''),
            ('eq', ''),
         ('xq', ''),
        )
        
        response = requests.get('https://search.shopping.naver.com/api/search/all', headers=headers, params=params)
        # 여기서부터 추가코드-----------------------------
        result_dict = json.loads(response.text)
        result_dict['shoppingResult']['products'] 
        for i in result_dict['shoppingResult']['products']:
            title = i['productTitle']
            price = i['price'] 
            registerdate = i['openDate']
            doc2 = {
                'title': title,
                'price': price,
                'registerdate': registerdate
                }
            doc2_list.append(doc2)
            
    except:
        break
with open("data2.json", "w") as f:
    json.dump(doc2_list, f)

#NB. Original query string below. It seems impossible to parse and
#reproduce query strings 100% accurately so the one below is given
#in case the reproduced version is not "correct".
# response = requests.get('https://search.shopping.naver.com/api/search/all?sort=rel&pagingIndex=1&pagingSize=80&viewType=list&productSet=total&deliveryFee=&deliveryTypeValue=&frm=NVSHATC&query=%EC%95%8C%EB%A3%A8%EB%AF%B8%EB%8A%84%ED%8C%90+T+MM&origQuery=%EC%95%8C%EB%A3%A8%EB%AF%B8%EB%8A%84%ED%8C%90+T+MM&iq=&eq=&xq=', headers=headers)




  



# import requests
# from bs4 import BeautifulSoup
# import urllib
# from selenium import webdriver
# from selenium.webdriver.common.keys import Keys
# import time


# def main():
#     options = webdriver.ChromeOptions()
#     options.add_experimental_option("excludeSwitches", ["enable-logging"])
#     driver = webdriver.Chrome(options=options)

#     url = ("https://search.shopping.naver.com/search/all?query=%EC%95%8C%EB%A3%A8%EB%AF%B8%EB%8A%84%ED%8C%90%20T%20MM&frm=NVSHATC&prevQuery=%EC%95%8C%EB%A3%A8%EB%AF%B8%EB%8A%84%ED%8C%90%20T" 
#             # "pagingIndex=1&"                         # 조회할 페이지번호
#             "pagingSize=" + "80&"   )                 # 페이지당 검색수
#             # "productSet=overseas&"                   # 해외직구
#             # "query&"                                 # query: 검색 키워드
#             # "sort=rel&"                              # sort=rel(네이버가격순)
#             # "timestamp=&"                            # 
#             # "viewType=list")                         # viewType=list(리스트보기)
    
#     driver.get(url)
    
#     # driver.find_element_by_css_selector(".subFilter_select_box__1bM64").click() 
#     # driver.find_element_by_css_selector(".subFilter_select__1eEJS").click() 
#     # SCROLL_PAUSE_TIME = 2

#     # bs = BeautifulSoup(urllib.request.urlopen(url),"html.parser")
    

#     # page=1
#     # doc2_list=[]
#     # while page < 11:
#     #     last_height = driver.execute_script("return document.body.scrollHeight")
#     #     while True:
#     #         driver.execute_script("window.scrollTo(0, document.body.scrollHeight);") # Scroll down to bottom
#     #         product_list = bs.select("li[class^='basicList_item__']")
#     #         for li in product_list:
#     #             for goods in li.contents:
#     #                 title = price = registerdate = 0
#     #                 title = goods.select("a[class^='basicList_link__']")[0].text
#     #                 price = goods.select("span[class^='price_num__']")[0].text
#     #                 registerdate = goods.select("div[class^='basicList_etc_box__'] > span")[0].text
#     #                 doc2 = {
#     #                     'title': title,
#     #                     'price': price,
#     #                     'registerdate': registerdate
#     #                     }
#     #                 doc2_list.append(doc2)
#     #             with open("data2.json", "w") as f:
#     #             json.dump(doc2_list, f)

#     #         time.sleep(SCROLL_PAUSE_TIME) # Wait to load page
         
#     #         # Calculate new scroll height and compare with last scroll height
#     #         new_height = driver.execute_script("return document.body.scrollHeight")
#     #         if new_height == last_height:
#     #             try:
#     #                 driver.find_element_by_css_selector(".mye4qd").click()
#     #             except:
#     #                 break
#     #         last_height = new_height    
        
#     #     next_btn = driver.find_element_by_class_name('pagination_next__1ITTf')
#     #     next_btn.click()
#     #     page += 1
    

# if __name__ == "__main__":
#     main()